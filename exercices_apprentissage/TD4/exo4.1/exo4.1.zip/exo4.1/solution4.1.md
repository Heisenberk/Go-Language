# TD4 Exercice 1 : Solution 

1. 