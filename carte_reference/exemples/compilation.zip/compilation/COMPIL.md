Dans $GOPATH/ : go build point/ && go install projet/
